<?php
header('Location: ../frontend/feindex.php');
exit;
?>