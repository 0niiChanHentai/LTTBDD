// let quantity = document.getElementById("quantity");

// function increase(i, n){
//     var x = i.parentElement;
//     n++;

// }