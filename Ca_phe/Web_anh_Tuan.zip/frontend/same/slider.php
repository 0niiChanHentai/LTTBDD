<div class="slideshow-container">
    <div class="mySlides fade">
        <img src="../frontend/picture/slider1.jpg">
    </div>
    <div class="mySlides fade">
        <img src="../frontend/picture/slider2.jpg">
    </div>
</div>