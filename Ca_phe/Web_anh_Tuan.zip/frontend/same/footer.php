<div>
    <ul>
        <li><h3>Phone</h3></li>
        <li>+0123456789</li>
    </ul>
</div>
<div>
    <ul>
        <li><h3>Address</h3></li>
        <li>Hai Phong</li>
    </ul>
</div>
<div>
    <ul>
        <li><h3>Email</h3></li>
        <li>CafeMoc24@gmail.com</li>
    </ul>
</div>
<div>
    <ul>
        <li><h3>Opening</h3></li>
        <li>8.00am - 10.00pm</li>
        <li>Mon-Sat</li>
    </ul>
</div>
<div>
    <ul>
        <li><h3>Follow us on</h3></li>
        <li>
            <div class="foot">    
                <img src="../frontend/picture/fb.png" alt="logo" width="30px" height="30px">
                <img src="../frontend/picture/tiktok.jpg" alt="logo" width="30px" height="30px">
            </div>
        </li>
    </ul>
</div>