<?php
    $conn = new PDO("mysql:serverhost=localhost:80;dbname=quancaphe",'student','123456')
?>