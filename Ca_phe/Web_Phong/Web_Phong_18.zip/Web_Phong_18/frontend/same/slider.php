<div class="slideshow-container">
    <div class="mySlides fade">
        <img src="../frontend/picture/slider1.jpg">
    </div>
    <div class="mySlides fade">
        <img src="../frontend/picture/slider2.jpg">
    </div>
    <a class="prev" onclick="subSlides(1)">❮</a>
    <a class="next" onclick="plusSlides(1)">❯</a>

</div>