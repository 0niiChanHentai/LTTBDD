let i = document.getElementById("quantity");

function increase(){
    alert('1');
}