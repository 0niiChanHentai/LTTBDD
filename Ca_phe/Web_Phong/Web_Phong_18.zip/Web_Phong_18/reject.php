<?php
    echo '<script>alert("Bạn không đủ quyền hạn");</script>';
    echo '<script>window.location.href = "doanh_thu/doanh_thu.php";</script>';
?>